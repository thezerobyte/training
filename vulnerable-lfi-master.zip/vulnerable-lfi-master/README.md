# Vulnerable-LFI
A simple, LFI vulnerable PHP application. This Repository was created to provide a follow-up of the vulnerable code used for the following articles: https://outpost24.com/blog/from-local-file-inclusion-to-remote-code-execution-part-1 

Please, do not hesitate to contact me for any possible questions at: nid[at]outpost24.com
